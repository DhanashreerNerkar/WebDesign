import './Footer.css';

function Footer()
{
    return(
        <footer className="footer">
            <p className="footer__disclaimer">
            Powered by - The Art of Music
            </p>
        </footer>
    );
}

export default Footer;
