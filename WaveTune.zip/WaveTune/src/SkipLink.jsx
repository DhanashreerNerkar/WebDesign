import React from 'react';
import './SkipLink.css';

const SkipLink = () => (
  <a href="#main-content" className="skipLink">Skip to main content</a>

);

export default SkipLink;
