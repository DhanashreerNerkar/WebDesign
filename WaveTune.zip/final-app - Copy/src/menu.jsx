const menu=[
    {name:"About",path:"#/"},
    {name:"Browse Songs",path:"#/about"},
    {name:"Subscribe",path:"#/subscribe"},
    {name:"Change Theme",path:"#/themeselection"}
];

export default menu;