import Registration from './Registration';
import './Subscribe.css';
function Subscribe()
{
    return(
        <>
        <div className='container'>
            <Registration /> 
        </div>
        </>
    );
} 
export default Subscribe;